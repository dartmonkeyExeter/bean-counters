# club penguin bean counters game
import pygame

pygame.init()
screen = pygame.display.set_mode((910, 575))
clock = pygame.time.Clock()

path = "C:/Users/aaronhampson/Downloads/bean counters/sprites/"

class Penguin:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.beans = 0
        self.sprites = [pygame.image.load(f"{path}/player/penguin{i}.png") for i in range(0, 6)]
        self.sprites = [pygame.transform.smoothscale_by(sprite, (1.25,1.25)) for sprite in self.sprites]
        self.image = self.sprites[0]
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        
    def draw(self):
        screen.blit(self.image, (self.x, self.y))

    def change_sprite(self):
        self.image = self.sprites[self.beans % 6]
    
    def collision(self, item):
        if self.rect.colliderect(item.rect):
            self.beans += 1
            items.remove(item)

class Bean:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.velocity = pygame.math.Vector2(0, 0)
        self.sprites = [pygame.image.load(f"{path}items/bean{i}.png") for i in range(0, 4)]
        self.sprites = [pygame.transform.smoothscale_by(sprite, (1.25,1.25)) for sprite in self.sprites]
        self.image = self.sprites[0]
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
    
    def draw(self):
        screen.blit(self.image, (self.x, self.y))
    
    def move(self):
        self.x += self.velocity.x
        self.y += self.velocity.y
        self.rect.x = self.x 
        self.rect.y = self.y 
items = []
spawn_location = [910 - 125, 575 / 2]

def spawn_bean():
    items.append(Bean(spawn_location[0], spawn_location[1]))
    

running = True
penguin = Penguin(910 / 2, 575 / 2)
spawn_bean()
while running:
    clock.tick(60)
    pygame.display.flip()
    screen.fill((255, 255, 255))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.MOUSEMOTION:
            penguin.x = event.pos[0] - penguin.rect.width // 2
            penguin.rect.x = penguin.x
        if event.type == pygame.MOUSEBUTTONDOWN:
            penguin.beans += 1
    
    penguin.change_sprite()
    penguin.draw()

    for item in items:
        item.move()
        item.draw()
        if item.x < 0:
            items.remove(item)
        penguin.collision(item)

